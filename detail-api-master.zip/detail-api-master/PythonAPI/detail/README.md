# setup

1. to run the demo, first download the dataset

```
# under detail-api

# download annotation:
mkdir json
python download.py trainval_withkeypoints json/

# download pascal dataset:
python download.py pascal  .

```

2. run

```
ipython notebook # start the notebook interface
```
